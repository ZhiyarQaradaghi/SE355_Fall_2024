import java.io.Serializable;

public class SayByeRequest implements Serializable{
}
