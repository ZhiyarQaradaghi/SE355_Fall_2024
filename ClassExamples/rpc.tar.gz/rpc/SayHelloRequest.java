import java.io.Serializable;

public class SayHelloRequest implements Serializable {
	public String name;
}
