public class BasicGreetingServiceImpl {

	public String sayHello(String name) {
		return "Hello " + name;
	}

	public String sayBye(){
		//code
		return "Bye";
	}
}
