public class GreetingService {
    public String sayHello(String name) {
        return "Hello "+name;
    }

    public String sayBye(String name) {
        return "Bye "+name;
    }
}