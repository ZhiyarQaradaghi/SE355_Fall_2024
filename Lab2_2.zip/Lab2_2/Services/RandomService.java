package Services;
public interface RandomService {
    public RandomNumberResponse generateRandom(); 
}