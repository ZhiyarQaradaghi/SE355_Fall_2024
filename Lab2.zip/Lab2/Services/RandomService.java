package Services;
public interface RandomService {
    public int generateRandomNumber();
    public int generateRandomDelay();
}