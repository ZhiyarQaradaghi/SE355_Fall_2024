package Services;
import java.util.Random;
public class RandomServiceImpl implements RandomService {
    Random randomNumber = new Random();
    public int generateRandomNumber() {
        int number = randomNumber.nextInt(999); 
        return number; 
    }

    public int generateRandomDelay() {
        return randomNumber.nextInt(1000); // ms  
    }
}
